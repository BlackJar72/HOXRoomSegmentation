using System.Collections.Generic;
using System.Collections;
using UnityEngine;


namespace kfutils.hox.factory {

    /// This is to be for generating segments.
    /// Should this be an actual class?  Or an interface for creating standardized, use specific classes.

    [System.Serializable]
    public class SegmentBuilder {

    }


}